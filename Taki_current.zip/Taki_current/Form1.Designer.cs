﻿namespace Taki_current
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.onered = new System.Windows.Forms.PictureBox();
            this.twored = new System.Windows.Forms.PictureBox();
            this.threered = new System.Windows.Forms.PictureBox();
            this.fourred = new System.Windows.Forms.PictureBox();
            this.fivered = new System.Windows.Forms.PictureBox();
            this.sixred = new System.Windows.Forms.PictureBox();
            this.sevenred = new System.Windows.Forms.PictureBox();
            this.eightred = new System.Windows.Forms.PictureBox();
            this.ninered = new System.Windows.Forms.PictureBox();
            this.plusred = new System.Windows.Forms.PictureBox();
            this.plustwored = new System.Windows.Forms.PictureBox();
            this.takired = new System.Windows.Forms.PictureBox();
            this.stopred = new System.Windows.Forms.PictureBox();
            this.chadirred = new System.Windows.Forms.PictureBox();
            this.oneblue = new System.Windows.Forms.PictureBox();
            this.twoblue = new System.Windows.Forms.PictureBox();
            this.threeblue = new System.Windows.Forms.PictureBox();
            this.fourblue = new System.Windows.Forms.PictureBox();
            this.fiveblue = new System.Windows.Forms.PictureBox();
            this.sixblue = new System.Windows.Forms.PictureBox();
            this.sevenblue = new System.Windows.Forms.PictureBox();
            this.eightblue = new System.Windows.Forms.PictureBox();
            this.nineblue = new System.Windows.Forms.PictureBox();
            this.plusblue = new System.Windows.Forms.PictureBox();
            this.plustwoblue = new System.Windows.Forms.PictureBox();
            this.takiblue = new System.Windows.Forms.PictureBox();
            this.chdirblue = new System.Windows.Forms.PictureBox();
            this.oneyellow = new System.Windows.Forms.PictureBox();
            this.twoyellow = new System.Windows.Forms.PictureBox();
            this.fouryellow = new System.Windows.Forms.PictureBox();
            this.threeyellow = new System.Windows.Forms.PictureBox();
            this.chadiryellow = new System.Windows.Forms.PictureBox();
            this.stopyellow = new System.Windows.Forms.PictureBox();
            this.onegreen = new System.Windows.Forms.PictureBox();
            this.twogreen = new System.Windows.Forms.PictureBox();
            this.threegreen = new System.Windows.Forms.PictureBox();
            this.fourgreen = new System.Windows.Forms.PictureBox();
            this.stopblue = new System.Windows.Forms.PictureBox();
            this.fiveyellow = new System.Windows.Forms.PictureBox();
            this.sixyellow = new System.Windows.Forms.PictureBox();
            this.chadirgreen = new System.Windows.Forms.PictureBox();
            this.plustwogreen = new System.Windows.Forms.PictureBox();
            this.plusgreen = new System.Windows.Forms.PictureBox();
            this.takiall = new System.Windows.Forms.PictureBox();
            this.chacolall = new System.Windows.Forms.PictureBox();
            this.takiyellow = new System.Windows.Forms.PictureBox();
            this.fivegreen = new System.Windows.Forms.PictureBox();
            this.sixgreen = new System.Windows.Forms.PictureBox();
            this.sevengreen = new System.Windows.Forms.PictureBox();
            this.eightgreen = new System.Windows.Forms.PictureBox();
            this.ninegreen = new System.Windows.Forms.PictureBox();
            this.stopgreen = new System.Windows.Forms.PictureBox();
            this.takigreen = new System.Windows.Forms.PictureBox();
            this.sevenyellow = new System.Windows.Forms.PictureBox();
            this.eightyellow = new System.Windows.Forms.PictureBox();
            this.nineyellow = new System.Windows.Forms.PictureBox();
            this.plusyellow = new System.Windows.Forms.PictureBox();
            this.plustwoyellow = new System.Windows.Forms.PictureBox();
            this.first_player = new System.Windows.Forms.Label();
            this.second_player = new System.Windows.Forms.Label();
            this.third_player = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.left = new System.Windows.Forms.PictureBox();
            this.right = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.onered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twored)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.threered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ninered)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwored)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.takired)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chadirred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oneblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwoblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.takiblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chdirblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oneyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fouryellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chadiryellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onegreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twogreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.threegreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chadirgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwogreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.takiall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chacolall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.takiyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivegreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevengreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ninegreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.takigreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwoyellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.left)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.right)).BeginInit();
            this.SuspendLayout();
            // 
            // onered
            // 
            this.onered.Image = ((System.Drawing.Image)(resources.GetObject("onered.Image")));
            this.onered.Location = new System.Drawing.Point(43, 618);
            this.onered.Name = "onered";
            this.onered.Size = new System.Drawing.Size(100, 150);
            this.onered.TabIndex = 0;
            this.onered.TabStop = false;
            // 
            // twored
            // 
            this.twored.Image = ((System.Drawing.Image)(resources.GetObject("twored.Image")));
            this.twored.Location = new System.Drawing.Point(43, 506);
            this.twored.Name = "twored";
            this.twored.Size = new System.Drawing.Size(100, 150);
            this.twored.TabIndex = 14;
            this.twored.TabStop = false;
            // 
            // threered
            // 
            this.threered.Image = ((System.Drawing.Image)(resources.GetObject("threered.Image")));
            this.threered.Location = new System.Drawing.Point(790, 618);
            this.threered.Name = "threered";
            this.threered.Size = new System.Drawing.Size(100, 150);
            this.threered.TabIndex = 2;
            this.threered.TabStop = false;
            // 
            // fourred
            // 
            this.fourred.Image = ((System.Drawing.Image)(resources.GetObject("fourred.Image")));
            this.fourred.Location = new System.Drawing.Point(707, 618);
            this.fourred.Name = "fourred";
            this.fourred.Size = new System.Drawing.Size(100, 150);
            this.fourred.TabIndex = 3;
            this.fourred.TabStop = false;
            // 
            // fivered
            // 
            this.fivered.Image = ((System.Drawing.Image)(resources.GetObject("fivered.Image")));
            this.fivered.Location = new System.Drawing.Point(624, 618);
            this.fivered.Name = "fivered";
            this.fivered.Size = new System.Drawing.Size(100, 150);
            this.fivered.TabIndex = 4;
            this.fivered.TabStop = false;
            // 
            // sixred
            // 
            this.sixred.Image = ((System.Drawing.Image)(resources.GetObject("sixred.Image")));
            this.sixred.Location = new System.Drawing.Point(541, 618);
            this.sixred.Name = "sixred";
            this.sixred.Size = new System.Drawing.Size(100, 150);
            this.sixred.TabIndex = 5;
            this.sixred.TabStop = false;
            // 
            // sevenred
            // 
            this.sevenred.Image = ((System.Drawing.Image)(resources.GetObject("sevenred.Image")));
            this.sevenred.Location = new System.Drawing.Point(458, 618);
            this.sevenred.Name = "sevenred";
            this.sevenred.Size = new System.Drawing.Size(100, 150);
            this.sevenred.TabIndex = 6;
            this.sevenred.TabStop = false;
            // 
            // eightred
            // 
            this.eightred.Image = ((System.Drawing.Image)(resources.GetObject("eightred.Image")));
            this.eightred.Location = new System.Drawing.Point(375, 618);
            this.eightred.Name = "eightred";
            this.eightred.Size = new System.Drawing.Size(100, 150);
            this.eightred.TabIndex = 7;
            this.eightred.TabStop = false;
            // 
            // ninered
            // 
            this.ninered.Image = ((System.Drawing.Image)(resources.GetObject("ninered.Image")));
            this.ninered.Location = new System.Drawing.Point(292, 618);
            this.ninered.Name = "ninered";
            this.ninered.Size = new System.Drawing.Size(100, 150);
            this.ninered.TabIndex = 8;
            this.ninered.TabStop = false;
            // 
            // plusred
            // 
            this.plusred.Image = ((System.Drawing.Image)(resources.GetObject("plusred.Image")));
            this.plusred.Location = new System.Drawing.Point(209, 618);
            this.plusred.Name = "plusred";
            this.plusred.Size = new System.Drawing.Size(100, 150);
            this.plusred.TabIndex = 9;
            this.plusred.TabStop = false;
            // 
            // plustwored
            // 
            this.plustwored.Image = ((System.Drawing.Image)(resources.GetObject("plustwored.Image")));
            this.plustwored.Location = new System.Drawing.Point(126, 618);
            this.plustwored.Name = "plustwored";
            this.plustwored.Size = new System.Drawing.Size(100, 150);
            this.plustwored.TabIndex = 10;
            this.plustwored.TabStop = false;
            // 
            // takired
            // 
            this.takired.Image = ((System.Drawing.Image)(resources.GetObject("takired.Image")));
            this.takired.Location = new System.Drawing.Point(874, 618);
            this.takired.Name = "takired";
            this.takired.Size = new System.Drawing.Size(100, 150);
            this.takired.TabIndex = 13;
            this.takired.TabStop = false;
            // 
            // stopred
            // 
            this.stopred.Image = ((System.Drawing.Image)(resources.GetObject("stopred.Image")));
            this.stopred.Location = new System.Drawing.Point(957, 618);
            this.stopred.Name = "stopred";
            this.stopred.Size = new System.Drawing.Size(100, 150);
            this.stopred.TabIndex = 12;
            this.stopred.TabStop = false;
            // 
            // chadirred
            // 
            this.chadirred.Image = ((System.Drawing.Image)(resources.GetObject("chadirred.Image")));
            this.chadirred.Location = new System.Drawing.Point(1040, 618);
            this.chadirred.Name = "chadirred";
            this.chadirred.Size = new System.Drawing.Size(100, 150);
            this.chadirred.TabIndex = 11;
            this.chadirred.TabStop = false;
            // 
            // oneblue
            // 
            this.oneblue.Image = ((System.Drawing.Image)(resources.GetObject("oneblue.Image")));
            this.oneblue.Location = new System.Drawing.Point(957, 506);
            this.oneblue.Name = "oneblue";
            this.oneblue.Size = new System.Drawing.Size(100, 150);
            this.oneblue.TabIndex = 15;
            this.oneblue.TabStop = false;
            // 
            // twoblue
            // 
            this.twoblue.Image = ((System.Drawing.Image)(resources.GetObject("twoblue.Image")));
            this.twoblue.Location = new System.Drawing.Point(873, 506);
            this.twoblue.Name = "twoblue";
            this.twoblue.Size = new System.Drawing.Size(100, 150);
            this.twoblue.TabIndex = 16;
            this.twoblue.TabStop = false;
            // 
            // threeblue
            // 
            this.threeblue.Image = ((System.Drawing.Image)(resources.GetObject("threeblue.Image")));
            this.threeblue.Location = new System.Drawing.Point(790, 506);
            this.threeblue.Name = "threeblue";
            this.threeblue.Size = new System.Drawing.Size(100, 150);
            this.threeblue.TabIndex = 17;
            this.threeblue.TabStop = false;
            // 
            // fourblue
            // 
            this.fourblue.Image = ((System.Drawing.Image)(resources.GetObject("fourblue.Image")));
            this.fourblue.Location = new System.Drawing.Point(638, 506);
            this.fourblue.Name = "fourblue";
            this.fourblue.Size = new System.Drawing.Size(100, 150);
            this.fourblue.TabIndex = 18;
            this.fourblue.TabStop = false;
            // 
            // fiveblue
            // 
            this.fiveblue.Image = ((System.Drawing.Image)(resources.GetObject("fiveblue.Image")));
            this.fiveblue.Location = new System.Drawing.Point(150, 100);
            this.fiveblue.Name = "fiveblue";
            this.fiveblue.Size = new System.Drawing.Size(100, 150);
            this.fiveblue.TabIndex = 19;
            this.fiveblue.TabStop = false;
            // 
            // sixblue
            // 
            this.sixblue.Image = ((System.Drawing.Image)(resources.GetObject("sixblue.Image")));
            this.sixblue.Location = new System.Drawing.Point(541, 506);
            this.sixblue.Name = "sixblue";
            this.sixblue.Size = new System.Drawing.Size(100, 150);
            this.sixblue.TabIndex = 20;
            this.sixblue.TabStop = false;
            // 
            // sevenblue
            // 
            this.sevenblue.Image = ((System.Drawing.Image)(resources.GetObject("sevenblue.Image")));
            this.sevenblue.Location = new System.Drawing.Point(458, 506);
            this.sevenblue.Name = "sevenblue";
            this.sevenblue.Size = new System.Drawing.Size(100, 150);
            this.sevenblue.TabIndex = 21;
            this.sevenblue.TabStop = false;
            // 
            // eightblue
            // 
            this.eightblue.Image = ((System.Drawing.Image)(resources.GetObject("eightblue.Image")));
            this.eightblue.Location = new System.Drawing.Point(375, 506);
            this.eightblue.Name = "eightblue";
            this.eightblue.Size = new System.Drawing.Size(100, 150);
            this.eightblue.TabIndex = 22;
            this.eightblue.TabStop = false;
            // 
            // nineblue
            // 
            this.nineblue.Image = ((System.Drawing.Image)(resources.GetObject("nineblue.Image")));
            this.nineblue.Location = new System.Drawing.Point(292, 506);
            this.nineblue.Name = "nineblue";
            this.nineblue.Size = new System.Drawing.Size(100, 150);
            this.nineblue.TabIndex = 23;
            this.nineblue.TabStop = false;
            // 
            // plusblue
            // 
            this.plusblue.Image = ((System.Drawing.Image)(resources.GetObject("plusblue.Image")));
            this.plusblue.Location = new System.Drawing.Point(209, 506);
            this.plusblue.Name = "plusblue";
            this.plusblue.Size = new System.Drawing.Size(100, 150);
            this.plusblue.TabIndex = 24;
            this.plusblue.TabStop = false;
            // 
            // plustwoblue
            // 
            this.plustwoblue.Image = ((System.Drawing.Image)(resources.GetObject("plustwoblue.Image")));
            this.plustwoblue.Location = new System.Drawing.Point(126, 506);
            this.plustwoblue.Name = "plustwoblue";
            this.plustwoblue.Size = new System.Drawing.Size(100, 150);
            this.plustwoblue.TabIndex = 25;
            this.plustwoblue.TabStop = false;
            // 
            // takiblue
            // 
            this.takiblue.Image = ((System.Drawing.Image)(resources.GetObject("takiblue.Image")));
            this.takiblue.Location = new System.Drawing.Point(1040, 506);
            this.takiblue.Name = "takiblue";
            this.takiblue.Size = new System.Drawing.Size(100, 150);
            this.takiblue.TabIndex = 26;
            this.takiblue.TabStop = false;
            // 
            // chdirblue
            // 
            this.chdirblue.Image = ((System.Drawing.Image)(resources.GetObject("chdirblue.Image")));
            this.chdirblue.Location = new System.Drawing.Point(1040, 394);
            this.chdirblue.Name = "chdirblue";
            this.chdirblue.Size = new System.Drawing.Size(100, 150);
            this.chdirblue.TabIndex = 39;
            this.chdirblue.TabStop = false;
            // 
            // oneyellow
            // 
            this.oneyellow.Image = ((System.Drawing.Image)(resources.GetObject("oneyellow.Image")));
            this.oneyellow.Location = new System.Drawing.Point(126, 394);
            this.oneyellow.Name = "oneyellow";
            this.oneyellow.Size = new System.Drawing.Size(100, 150);
            this.oneyellow.TabIndex = 38;
            this.oneyellow.TabStop = false;
            // 
            // twoyellow
            // 
            this.twoyellow.Image = ((System.Drawing.Image)(resources.GetObject("twoyellow.Image")));
            this.twoyellow.Location = new System.Drawing.Point(209, 394);
            this.twoyellow.Name = "twoyellow";
            this.twoyellow.Size = new System.Drawing.Size(100, 150);
            this.twoyellow.TabIndex = 37;
            this.twoyellow.TabStop = false;
            // 
            // fouryellow
            // 
            this.fouryellow.Image = ((System.Drawing.Image)(resources.GetObject("fouryellow.Image")));
            this.fouryellow.Location = new System.Drawing.Point(292, 394);
            this.fouryellow.Name = "fouryellow";
            this.fouryellow.Size = new System.Drawing.Size(100, 150);
            this.fouryellow.TabIndex = 36;
            this.fouryellow.TabStop = false;
            // 
            // threeyellow
            // 
            this.threeyellow.Image = ((System.Drawing.Image)(resources.GetObject("threeyellow.Image")));
            this.threeyellow.Location = new System.Drawing.Point(375, 394);
            this.threeyellow.Name = "threeyellow";
            this.threeyellow.Size = new System.Drawing.Size(100, 150);
            this.threeyellow.TabIndex = 35;
            this.threeyellow.TabStop = false;
            // 
            // chadiryellow
            // 
            this.chadiryellow.Image = ((System.Drawing.Image)(resources.GetObject("chadiryellow.Image")));
            this.chadiryellow.Location = new System.Drawing.Point(458, 394);
            this.chadiryellow.Name = "chadiryellow";
            this.chadiryellow.Size = new System.Drawing.Size(100, 150);
            this.chadiryellow.TabIndex = 34;
            this.chadiryellow.TabStop = false;
            // 
            // stopyellow
            // 
            this.stopyellow.Image = ((System.Drawing.Image)(resources.GetObject("stopyellow.Image")));
            this.stopyellow.Location = new System.Drawing.Point(541, 394);
            this.stopyellow.Name = "stopyellow";
            this.stopyellow.Size = new System.Drawing.Size(100, 150);
            this.stopyellow.TabIndex = 33;
            this.stopyellow.TabStop = false;
            // 
            // onegreen
            // 
            this.onegreen.Image = ((System.Drawing.Image)(resources.GetObject("onegreen.Image")));
            this.onegreen.Location = new System.Drawing.Point(624, 394);
            this.onegreen.Name = "onegreen";
            this.onegreen.Size = new System.Drawing.Size(100, 150);
            this.onegreen.TabIndex = 32;
            this.onegreen.TabStop = false;
            // 
            // twogreen
            // 
            this.twogreen.Image = ((System.Drawing.Image)(resources.GetObject("twogreen.Image")));
            this.twogreen.Location = new System.Drawing.Point(707, 394);
            this.twogreen.Name = "twogreen";
            this.twogreen.Size = new System.Drawing.Size(100, 150);
            this.twogreen.TabIndex = 31;
            this.twogreen.TabStop = false;
            // 
            // threegreen
            // 
            this.threegreen.Image = ((System.Drawing.Image)(resources.GetObject("threegreen.Image")));
            this.threegreen.Location = new System.Drawing.Point(790, 394);
            this.threegreen.Name = "threegreen";
            this.threegreen.Size = new System.Drawing.Size(100, 150);
            this.threegreen.TabIndex = 30;
            this.threegreen.TabStop = false;
            // 
            // fourgreen
            // 
            this.fourgreen.Image = ((System.Drawing.Image)(resources.GetObject("fourgreen.Image")));
            this.fourgreen.Location = new System.Drawing.Point(873, 394);
            this.fourgreen.Name = "fourgreen";
            this.fourgreen.Size = new System.Drawing.Size(100, 150);
            this.fourgreen.TabIndex = 29;
            this.fourgreen.TabStop = false;
            // 
            // stopblue
            // 
            this.stopblue.Image = ((System.Drawing.Image)(resources.GetObject("stopblue.Image")));
            this.stopblue.Location = new System.Drawing.Point(957, 394);
            this.stopblue.Name = "stopblue";
            this.stopblue.Size = new System.Drawing.Size(100, 150);
            this.stopblue.TabIndex = 28;
            this.stopblue.TabStop = false;
            // 
            // fiveyellow
            // 
            this.fiveyellow.Image = ((System.Drawing.Image)(resources.GetObject("fiveyellow.Image")));
            this.fiveyellow.Location = new System.Drawing.Point(43, 394);
            this.fiveyellow.Name = "fiveyellow";
            this.fiveyellow.Size = new System.Drawing.Size(100, 150);
            this.fiveyellow.TabIndex = 27;
            this.fiveyellow.TabStop = false;
            // 
            // sixyellow
            // 
            this.sixyellow.Image = ((System.Drawing.Image)(resources.GetObject("sixyellow.Image")));
            this.sixyellow.Location = new System.Drawing.Point(43, 280);
            this.sixyellow.Name = "sixyellow";
            this.sixyellow.Size = new System.Drawing.Size(100, 150);
            this.sixyellow.TabIndex = 65;
            this.sixyellow.TabStop = false;
            // 
            // chadirgreen
            // 
            this.chadirgreen.Image = ((System.Drawing.Image)(resources.GetObject("chadirgreen.Image")));
            this.chadirgreen.Location = new System.Drawing.Point(126, 168);
            this.chadirgreen.Name = "chadirgreen";
            this.chadirgreen.Size = new System.Drawing.Size(100, 150);
            this.chadirgreen.TabIndex = 64;
            this.chadirgreen.TabStop = false;
            // 
            // plustwogreen
            // 
            this.plustwogreen.Image = ((System.Drawing.Image)(resources.GetObject("plustwogreen.Image")));
            this.plustwogreen.Location = new System.Drawing.Point(209, 168);
            this.plustwogreen.Name = "plustwogreen";
            this.plustwogreen.Size = new System.Drawing.Size(100, 150);
            this.plustwogreen.TabIndex = 63;
            this.plustwogreen.TabStop = false;
            // 
            // plusgreen
            // 
            this.plusgreen.Image = ((System.Drawing.Image)(resources.GetObject("plusgreen.Image")));
            this.plusgreen.Location = new System.Drawing.Point(292, 168);
            this.plusgreen.Name = "plusgreen";
            this.plusgreen.Size = new System.Drawing.Size(100, 150);
            this.plusgreen.TabIndex = 62;
            this.plusgreen.TabStop = false;
            // 
            // takiall
            // 
            this.takiall.Image = ((System.Drawing.Image)(resources.GetObject("takiall.Image")));
            this.takiall.Location = new System.Drawing.Point(375, 168);
            this.takiall.Name = "takiall";
            this.takiall.Size = new System.Drawing.Size(100, 150);
            this.takiall.TabIndex = 61;
            this.takiall.TabStop = false;
            // 
            // chacolall
            // 
            this.chacolall.Image = ((System.Drawing.Image)(resources.GetObject("chacolall.Image")));
            this.chacolall.Location = new System.Drawing.Point(458, 168);
            this.chacolall.Name = "chacolall";
            this.chacolall.Size = new System.Drawing.Size(100, 150);
            this.chacolall.TabIndex = 60;
            this.chacolall.TabStop = false;
            // 
            // takiyellow
            // 
            this.takiyellow.Image = ((System.Drawing.Image)(resources.GetObject("takiyellow.Image")));
            this.takiyellow.Location = new System.Drawing.Point(541, 280);
            this.takiyellow.Name = "takiyellow";
            this.takiyellow.Size = new System.Drawing.Size(100, 150);
            this.takiyellow.TabIndex = 59;
            this.takiyellow.TabStop = false;
            // 
            // fivegreen
            // 
            this.fivegreen.Image = ((System.Drawing.Image)(resources.GetObject("fivegreen.Image")));
            this.fivegreen.Location = new System.Drawing.Point(624, 280);
            this.fivegreen.Name = "fivegreen";
            this.fivegreen.Size = new System.Drawing.Size(100, 150);
            this.fivegreen.TabIndex = 58;
            this.fivegreen.TabStop = false;
            // 
            // sixgreen
            // 
            this.sixgreen.Image = ((System.Drawing.Image)(resources.GetObject("sixgreen.Image")));
            this.sixgreen.Location = new System.Drawing.Point(707, 280);
            this.sixgreen.Name = "sixgreen";
            this.sixgreen.Size = new System.Drawing.Size(100, 150);
            this.sixgreen.TabIndex = 57;
            this.sixgreen.TabStop = false;
            // 
            // sevengreen
            // 
            this.sevengreen.Image = ((System.Drawing.Image)(resources.GetObject("sevengreen.Image")));
            this.sevengreen.Location = new System.Drawing.Point(790, 280);
            this.sevengreen.Name = "sevengreen";
            this.sevengreen.Size = new System.Drawing.Size(100, 150);
            this.sevengreen.TabIndex = 56;
            this.sevengreen.TabStop = false;
            // 
            // eightgreen
            // 
            this.eightgreen.Image = ((System.Drawing.Image)(resources.GetObject("eightgreen.Image")));
            this.eightgreen.Location = new System.Drawing.Point(873, 280);
            this.eightgreen.Name = "eightgreen";
            this.eightgreen.Size = new System.Drawing.Size(100, 150);
            this.eightgreen.TabIndex = 55;
            this.eightgreen.TabStop = false;
            // 
            // ninegreen
            // 
            this.ninegreen.Image = ((System.Drawing.Image)(resources.GetObject("ninegreen.Image")));
            this.ninegreen.Location = new System.Drawing.Point(957, 280);
            this.ninegreen.Name = "ninegreen";
            this.ninegreen.Size = new System.Drawing.Size(100, 150);
            this.ninegreen.TabIndex = 54;
            this.ninegreen.TabStop = false;
            // 
            // stopgreen
            // 
            this.stopgreen.Image = ((System.Drawing.Image)(resources.GetObject("stopgreen.Image")));
            this.stopgreen.Location = new System.Drawing.Point(43, 168);
            this.stopgreen.Name = "stopgreen";
            this.stopgreen.Size = new System.Drawing.Size(100, 150);
            this.stopgreen.TabIndex = 53;
            this.stopgreen.TabStop = false;
            // 
            // takigreen
            // 
            this.takigreen.Image = ((System.Drawing.Image)(resources.GetObject("takigreen.Image")));
            this.takigreen.Location = new System.Drawing.Point(1040, 280);
            this.takigreen.Name = "takigreen";
            this.takigreen.Size = new System.Drawing.Size(100, 150);
            this.takigreen.TabIndex = 52;
            this.takigreen.TabStop = false;
            // 
            // sevenyellow
            // 
            this.sevenyellow.Image = ((System.Drawing.Image)(resources.GetObject("sevenyellow.Image")));
            this.sevenyellow.Location = new System.Drawing.Point(126, 280);
            this.sevenyellow.Name = "sevenyellow";
            this.sevenyellow.Size = new System.Drawing.Size(100, 150);
            this.sevenyellow.TabIndex = 51;
            this.sevenyellow.TabStop = false;
            // 
            // eightyellow
            // 
            this.eightyellow.Image = ((System.Drawing.Image)(resources.GetObject("eightyellow.Image")));
            this.eightyellow.Location = new System.Drawing.Point(209, 280);
            this.eightyellow.Name = "eightyellow";
            this.eightyellow.Size = new System.Drawing.Size(100, 150);
            this.eightyellow.TabIndex = 50;
            this.eightyellow.TabStop = false;
            // 
            // nineyellow
            // 
            this.nineyellow.Image = ((System.Drawing.Image)(resources.GetObject("nineyellow.Image")));
            this.nineyellow.Location = new System.Drawing.Point(292, 280);
            this.nineyellow.Name = "nineyellow";
            this.nineyellow.Size = new System.Drawing.Size(100, 150);
            this.nineyellow.TabIndex = 49;
            this.nineyellow.TabStop = false;
            // 
            // plusyellow
            // 
            this.plusyellow.Image = ((System.Drawing.Image)(resources.GetObject("plusyellow.Image")));
            this.plusyellow.Location = new System.Drawing.Point(375, 280);
            this.plusyellow.Name = "plusyellow";
            this.plusyellow.Size = new System.Drawing.Size(100, 150);
            this.plusyellow.TabIndex = 48;
            this.plusyellow.TabStop = false;
            // 
            // plustwoyellow
            // 
            this.plustwoyellow.Image = ((System.Drawing.Image)(resources.GetObject("plustwoyellow.Image")));
            this.plustwoyellow.Location = new System.Drawing.Point(458, 280);
            this.plustwoyellow.Name = "plustwoyellow";
            this.plustwoyellow.Size = new System.Drawing.Size(100, 50);
            this.plustwoyellow.TabIndex = 47;
            this.plustwoyellow.TabStop = false;
            // 
            // first_player
            // 
            this.first_player.AutoEllipsis = true;
            this.first_player.BackColor = System.Drawing.SystemColors.Info;
            this.first_player.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first_player.ForeColor = System.Drawing.SystemColors.ControlText;
            this.first_player.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.first_player.Location = new System.Drawing.Point(1661, 422);
            this.first_player.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.first_player.Name = "first_player";
            this.first_player.Size = new System.Drawing.Size(334, 205);
            this.first_player.TabIndex = 0;
            this.first_player.Text = "0";
            this.first_player.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // second_player
            // 
            this.second_player.BackColor = System.Drawing.SystemColors.Info;
            this.second_player.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.second_player.ForeColor = System.Drawing.SystemColors.ControlText;
            this.second_player.Location = new System.Drawing.Point(891, 41);
            this.second_player.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.second_player.Name = "second_player";
            this.second_player.Size = new System.Drawing.Size(332, 205);
            this.second_player.TabIndex = 1;
            this.second_player.Text = "0";
            this.second_player.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // third_player
            // 
            this.third_player.BackColor = System.Drawing.SystemColors.Info;
            this.third_player.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.third_player.ForeColor = System.Drawing.SystemColors.ControlText;
            this.third_player.Location = new System.Drawing.Point(120, 422);
            this.third_player.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.third_player.Name = "third_player";
            this.third_player.Size = new System.Drawing.Size(334, 205);
            this.third_player.TabIndex = 2;
            this.third_player.Text = "0";
            this.third_player.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(814, 391);
            this.panel1.Margin = new System.Windows.Forms.Padding(6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(480, 404);
            this.panel1.TabIndex = 4;
            this.panel1.Visible = false;
            // 
            // left
            // 
            this.left.Image = ((System.Drawing.Image)(resources.GetObject("left.Image")));
            this.left.Location = new System.Drawing.Point(688, 28);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(100, 100);
            this.left.TabIndex = 5;
            this.left.TabStop = false;
            // 
            // right
            // 
            this.right.Image = ((System.Drawing.Image)(resources.GetObject("right.Image")));
            this.right.Location = new System.Drawing.Point(1330, 28);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(100, 100);
            this.right.TabIndex = 6;
            this.right.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(2151, 2036);
            this.Controls.Add(this.third_player);
            this.Controls.Add(this.second_player);
            this.Controls.Add(this.first_player);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.onered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twored)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.threered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ninered)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwored)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.takired)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chadirred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oneblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwoblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.takiblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chdirblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oneyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fouryellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chadiryellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onegreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twogreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.threegreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chadirgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwogreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.takiall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chacolall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.takiyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivegreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevengreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ninegreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.takigreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plustwoyellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.left)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.right)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox onered;
        private System.Windows.Forms.PictureBox threered;
        private System.Windows.Forms.PictureBox fourred;
        private System.Windows.Forms.PictureBox fivered;
        private System.Windows.Forms.PictureBox sixred;
        private System.Windows.Forms.PictureBox sevenred;
        private System.Windows.Forms.PictureBox eightred;
        private System.Windows.Forms.PictureBox ninered;
        private System.Windows.Forms.PictureBox plusred;
        private System.Windows.Forms.PictureBox plustwored;
        private System.Windows.Forms.PictureBox takired;
        private System.Windows.Forms.PictureBox stopred;
        private System.Windows.Forms.PictureBox chadirred;
        private System.Windows.Forms.PictureBox twored;
        private System.Windows.Forms.PictureBox oneblue;
        private System.Windows.Forms.PictureBox twoblue;
        private System.Windows.Forms.PictureBox threeblue;
        private System.Windows.Forms.PictureBox fourblue;
        private System.Windows.Forms.PictureBox fiveblue;
        private System.Windows.Forms.PictureBox sixblue;
        private System.Windows.Forms.PictureBox sevenblue;
        private System.Windows.Forms.PictureBox eightblue;
        private System.Windows.Forms.PictureBox nineblue;
        private System.Windows.Forms.PictureBox plusblue;
        private System.Windows.Forms.PictureBox plustwoblue;
        private System.Windows.Forms.PictureBox takiblue;
        private System.Windows.Forms.PictureBox chdirblue;
        private System.Windows.Forms.PictureBox oneyellow;
        private System.Windows.Forms.PictureBox twoyellow;
        private System.Windows.Forms.PictureBox fouryellow;
        private System.Windows.Forms.PictureBox threeyellow;
        private System.Windows.Forms.PictureBox chadiryellow;
        private System.Windows.Forms.PictureBox stopyellow;
        private System.Windows.Forms.PictureBox onegreen;
        private System.Windows.Forms.PictureBox twogreen;
        private System.Windows.Forms.PictureBox threegreen;
        private System.Windows.Forms.PictureBox fourgreen;
        private System.Windows.Forms.PictureBox stopblue;
        private System.Windows.Forms.PictureBox fiveyellow;
        private System.Windows.Forms.PictureBox sixyellow;
        private System.Windows.Forms.PictureBox chadirgreen;
        private System.Windows.Forms.PictureBox plustwogreen;
        private System.Windows.Forms.PictureBox plusgreen;
        private System.Windows.Forms.PictureBox takiall;
        private System.Windows.Forms.PictureBox chacolall;
        private System.Windows.Forms.PictureBox takiyellow;
        private System.Windows.Forms.PictureBox fivegreen;
        private System.Windows.Forms.PictureBox sixgreen;
        private System.Windows.Forms.PictureBox sevengreen;
        private System.Windows.Forms.PictureBox eightgreen;
        private System.Windows.Forms.PictureBox ninegreen;
        private System.Windows.Forms.PictureBox stopgreen;
        private System.Windows.Forms.PictureBox takigreen;
        private System.Windows.Forms.PictureBox sevenyellow;
        private System.Windows.Forms.PictureBox eightyellow;
        private System.Windows.Forms.PictureBox nineyellow;
        private System.Windows.Forms.PictureBox plusyellow;
        private System.Windows.Forms.PictureBox plustwoyellow;
        private System.Windows.Forms.Label first_player;
        private System.Windows.Forms.Label second_player;
        private System.Windows.Forms.Label third_player;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox left;
        private System.Windows.Forms.PictureBox right;
    }
}

